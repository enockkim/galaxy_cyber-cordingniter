 <!DOCTYPE html>
<html class="no-js" lang="eng">
<head>
	<?php include "includes_top.php"?>

</head>

<body data-home-page="https://website296449.nicepage.io/Page-2.html?version=100a7736-cb6c-46e4-906d-2484332ae0d0"
  data-home-page-title="Page 2" class="u-body">
  <section class="u-align-left u-clearfix u-image u-section-1" id="carousel_3e8e" data-image-width="1980"
    data-image-height="1350">
    <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
      <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
        <div class="u-gutter-0 u-layout">
          <div class="u-layout-row">
            <div
              class="u-align-left u-container-style u-layout-cell u-left-cell u-shape-rectangle u-size-27 u-layout-cell-1">
              <div class="u-container-layout u-container-layout-1">

                <h1 class="u-custom-font u-text u-text-body-alt-color u-text-1" spellcheck="false">Galaxy Cyber</h1>
                <p class="u-text u-text-body-alt-color u-text-2" spellcheck="false">All you cyber services at one place
                </p>
                <a href="#carousel_7a8d"
                  class="u-active-palette-4-base u-btn u-btn-round u-button-style u-custom-font u-font-raleway u-hover-palette-4-base u-palette-1-base u-radius-50 u-text-body-alt-color u-btn-1">FIND
                  US</a>
                  <p class="u-text u-text-body-alt-color u-text-2" spellcheck="false">OR
                </p>
                <a href="#" onclick="showOrderModal('<?php echo base_url();?>order/order_crud/add')"  class="u-active-palette-4-base u-btn u-btn-round u-button-style u-custom-font u-font-raleway u-hover-palette-4-base u-palette-1-base u-radius-50 u-text-body-alt-color u-btn-1">
						      Order Now
                </a>
              </div>
            </div>
            <div class="u-align-left u-container-style u-image u-layout-cell u-right-cell u-size-33 u-image-1"
              data-image-width="1372" data-image-height="1235">
              <div class="u-container-layout u-valign-bottom u-container-layout-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="u-align-center u-clearfix u-grey-10 u-section-7" id="">
    <h2 class="u-text u-text-1">Some of our Services</h2>
    <div class="row resize"> 
      <div class="column">
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo1.png" style="width:100%">
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo2.png" style="width:100%">
      </div>
      <div class="column">        
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo3.jpg" style="width:100%">
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo4.jpg" style="width:100%">
      </div>
      <div class="column">        
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo5.png" style="width:100%">
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo6.png" style="width:100%">
      </div>
      <div class="column">
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo7.jpg" style="width:100%">
        <img src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/images/logo8.png" style="width:100%">
      </div>
    </div>
<!-- 

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Order Services</h5>
      </div>
      <div class="modal-body">
      <form method="post" action="<?php echo base_url()?>order/make_order">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" name="name">
        </div>
        <div class="form-group">
            <label for="phoneNumber">Phone Number</label>
            <input type="text" class="form-control" name="phoneNumber">
        </div>
        <div class="form-group">
            <label for="service">Service</label>
            <select class="form-control" name="service">
            <option>KRA</option>
            <option>NEMA</option>
            <option>AGPO</option>
            <option>NEMIS</option>
            <option>NTSA</option>
            <option>TSA</option>
            <option>Invitation Cards</option>
            <option>Other</option>
            </select>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" name="description" rows="3"></textarea>
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
    </div>
  </div>
</div> -->


  <section class="u-clearfix u-white u-section-5" id="sec-d1be">
    <div class="u-clearfix u-sheet u-sheet-1">
      <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
          <div class="u-layout-row">
            <div class="u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-1">
              <div class="u-container-layout u-valign-top u-container-layout-1">
                <h1 class="u-text u-text-body-color u-text-1" spellcheck="false">All our services are offered with
                  affordable prices.</h1>
                <div class="u-border-6 u-border-palette-1-base u-line u-line-horizontal u-line-1"></div>
              </div>
            </div>
            <div class="u-container-style u-layout-cell u-right-cell u-size-30 u-layout-cell-2">
              <div class="u-container-layout u-valign-top u-container-layout-2">
                <p class="u-text u-text-black u-text-2">
                  Here at Galaxy Cyber we provide our cutomers quality services at affordable prices. Our customers leave happy and satisfied.
                </p>
                <!-- <a data-toggle="modal" data-target="#myModal"
                  class="u-active-palette-4-base u-btn u-btn-round u-button-style u-custom-font u-font-raleway u-hover-palette-4-base u-palette-1-base u-radius-50 u-text-body-alt-color u-btn-1">
                Order Now</a> -->
                <a href="#" onclick="showOrderModal('<?php echo base_url();?>admin/order_crud/add')"  class="u-active-palette-4-base u-btn u-btn-round u-button-style u-custom-font u-font-raleway u-hover-palette-4-base u-palette-1-base u-radius-50 u-text-body-alt-color u-btn-1">
						      Order Now
                </a>
              </div>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </div>

  </section>
  <section class="u-align-center u-clearfix u-palette-2-base u-section-6" id="carousel_7a8d">
    <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
      <h1 class="u-text u-text-1">Get in Touch!<br>
      </h1>
      <p class="u-text u-text-2">Come and let us work for you.</p>
      <div class="u-clearfix u-gutter-30 u-layout-wrap u-layout-wrap-1">
        <div class="u-gutter-0 u-layout">
          <div class="u-layout-col">
            <div class="u-size-60">
              <div class="u-layout-row">
                <div
                  class="u-align-center u-container-style u-layout-cell u-left-cell u-size-20 u-white u-layout-cell-1">
                  <div class="u-container-layout u-valign-top u-container-layout-1"><span
                      class="u-border-3 u-border-grey-15 u-icon u-icon-circle u-spacing-20 u-text-grey-40 u-icon-1"><svg
                        class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style="">
                        <use xlink:href="#svg-a501"></use>
                      </svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                        version="1.1" id="svg-a501" x="0px" y="0px" viewBox="0 0 512 512"
                        style="enable-background:new 0 0 512 512;" xml:space="preserve" class="u-svg-content">
                        <g>
                          <g>
                            <path
                              d="M256,0C156.748,0,76,80.748,76,180c0,33.534,9.289,66.26,26.869,94.652l142.885,230.257    c2.737,4.411,7.559,7.091,12.745,7.091c0.04,0,0.079,0,0.119,0c5.231-0.041,10.063-2.804,12.75-7.292L410.611,272.22    C427.221,244.428,436,212.539,436,180C436,80.748,355.252,0,256,0z M384.866,256.818L258.272,468.186l-129.905-209.34    C113.734,235.214,105.8,207.95,105.8,180c0-82.71,67.49-150.2,150.2-150.2S406.1,97.29,406.1,180    C406.1,207.121,398.689,233.688,384.866,256.818z">
                            </path>
                          </g>
                        </g>
                        <g>
                          <g>
                            <path
                              d="M256,90c-49.626,0-90,40.374-90,90c0,49.309,39.717,90,90,90c50.903,0,90-41.233,90-90C346,130.374,305.626,90,256,90z     M256,240.2c-33.257,0-60.2-27.033-60.2-60.2c0-33.084,27.116-60.2,60.2-60.2s60.1,27.116,60.1,60.2    C316.1,212.683,289.784,240.2,256,240.2z">
                            </path>
                          </g>
                        </g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                      </svg></span>
                    <h5 class="u-text u-text-grey-40 u-text-3">Location:</h5>
                    <p class="u-text u-text-4">Boito Centre<br>Along Koiwa road
                    </p>
                  </div>
                </div>
                <div class="u-container-style u-layout-cell u-size-20 u-white u-layout-cell-2">
                  <div class="u-container-layout u-valign-top u-container-layout-2"><span
                      class="u-border-3 u-border-grey-15 u-icon u-icon-circle u-spacing-20 u-text-grey-40 u-icon-2"><svg
                        class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 479.058 479.058" style="">
                        <use xlink:href="#svg-1497"></use>
                      </svg><svg xmlns="http://www.w3.org/2000/svg" id="svg-1497"
                        enable-background="new 0 0 479.058 479.058" viewBox="0 0 479.058 479.058" class="u-svg-content">
                        <path
                          d="m434.146 59.882h-389.234c-24.766 0-44.912 20.146-44.912 44.912v269.47c0 24.766 20.146 44.912 44.912 44.912h389.234c24.766 0 44.912-20.146 44.912-44.912v-269.47c0-24.766-20.146-44.912-44.912-44.912zm0 29.941c2.034 0 3.969.422 5.738 1.159l-200.355 173.649-200.356-173.649c1.769-.736 3.704-1.159 5.738-1.159zm0 299.411h-389.234c-8.26 0-14.971-6.71-14.971-14.971v-251.648l199.778 173.141c2.822 2.441 6.316 3.655 9.81 3.655s6.988-1.213 9.81-3.655l199.778-173.141v251.649c-.001 8.26-6.711 14.97-14.971 14.97z">
                        </path>
                      </svg></span>
                    <h5 class="u-align-center u-text u-text-grey-40 u-text-5">Email:</h5>
                    <a href="#"
                      class="u-border-active-none u-border-hover-none u-btn u-btn-rectangle u-button-style u-none u-text-body-color u-text-hover-palette-2-base u-btn-1">galaxycyber@gmail.com</a>
                   </div>
                </div>
                <div
                  class="u-align-center u-container-style u-layout-cell u-right-cell u-size-20 u-white u-layout-cell-3">
                  <div class="u-container-layout u-valign-top u-container-layout-3"><span
                      class="u-border-3 u-border-grey-15 u-icon u-icon-circle u-spacing-20 u-text-grey-40 u-icon-3"><svg
                        class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 384 384" style="">
                        <use xlink:href="#svg-1a9d"></use>
                      </svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                        version="1.1" id="svg-1a9d" x="0px" y="0px" viewBox="0 0 384 384"
                        style="enable-background:new 0 0 384 384;" xml:space="preserve" class="u-svg-content">
                        <g>
                          <g>
                            <path
                              d="M353.188,252.052c-23.51,0-46.594-3.677-68.469-10.906c-10.906-3.719-23.323-0.833-30.438,6.417l-43.177,32.594    c-50.073-26.729-80.917-57.563-107.281-107.26l31.635-42.052c8.219-8.208,11.167-20.198,7.635-31.448    c-7.26-21.99-10.948-45.063-10.948-68.583C132.146,13.823,118.323,0,101.333,0H30.812C13.823,0,0,13.823,0,30.812    C0,225.563,158.438,384,353.188,384c16.99,0,30.813-13.823,30.813-30.813v-70.323C384,265.875,370.177,252.052,353.188,252.052z     M362.667,353.188c0,5.229-4.25,9.479-9.479,9.479c-182.99,0-331.854-148.865-331.854-331.854c0-5.229,4.25-9.479,9.479-9.479    h70.521c5.229,0,9.479,4.25,9.479,9.479c0,25.802,4.052,51.125,11.979,75.115c1.104,3.542,0.208,7.208-3.375,10.938L82.75,165.427    c-2.458,3.26-2.844,7.625-1,11.26c29.927,58.823,66.292,95.188,125.531,125.542c3.604,1.885,8.021,1.49,11.292-0.979    l49.677-37.635c2.51-2.51,6.271-3.406,9.667-2.25c24.156,7.979,49.479,12.021,75.271,12.021c5.229,0,9.479,4.25,9.479,9.479    V353.188z">
                            </path>
                          </g>
                        </g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                        <g></g>
                      </svg></span>
                    <h5 class="u-text u-text-grey-40 u-text-6">Call | Text | WhatsApp</h5>
                    <p class="u-text u-text-7">0712 536 902<br>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php include "modal.php"?>
  <script src="http://localhost/e-waste/components/assets/js/compressed.js"></script>
  <script src="http://localhost/e-waste/components/assets/js/main.js"></script>
    <!-- <script src="http://localhost/e-waste/components/assets//switcher.js"></script> -->

<!-- dashboard libs -->

    <!-- events calendar -->
    <script src="http://localhost/e-waste/components/assets/js/admin/moment.min.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/fullcalendar.min.js"></script>
    <!-- range picker -->
    <script src="http://localhost/e-waste/components/assets/js/admin/daterangepicker.js"></script>

    <!-- charts -->
    <script src="http://localhost/e-waste/components/assets/js/admin/Chart.bundle.min.js"></script>
    <!-- vector map -->
    <script src="components/assets/js/admin/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="components/assets/js/admin/jquery-jvectormap-world-mill.js"></script>
    <!-- small charts -->
    <script src="http://localhost/e-waste/components/assets/js/admin/jquery.sparkline.min.js"></script>

    <!-- dashboard init -->
        <!-- This is data table -->
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/datatables.min.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/dataTables.buttons.min.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/buttons.flash.min.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/jszip.min.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/pdfmake.min.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/vfs_fonts.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/buttons.html5.min.js"></script>
    <script src="http://localhost/e-waste/components/assets/js/admin/datatables/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->
  <script src="<?php echo base_url(); ?>components/customs/register.js"></script>
</body>

</html>