<?php if (
    $page_name=='homepage'
){?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="keywords" content="Advertising agency">
  <meta name="description" content="">
  <meta name="page_type" content="np-template-header-footer-from-plugin">
  <title>Page 2</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
  <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->

  <!-- <link rel="stylesheet" href="nicepage.css" media="screen"> -->
  <link href="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/nicepage.css" media="screen" rel="stylesheet">
  <!-- <link rel="stylesheet" href="Page-2.css" media="screen"> -->
  <link href="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/Page-2.css" media="screen" rel="stylesheet">
  <!-- <script class="u-script" type="text/javascript" src="jquery-1.9.1.min.js" defer=""></script> -->
  <!-- <script class="u-script" type="text/javascript" src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/jquery-1.9.1.min.js" defer=""></script> -->
  <!-- <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script> -->
  <script class="u-script" type="text/javascript" src="http://lifewaychristianacademy.sc.ke/galaxy_cyber1/nicepage.js" defer=""></script>
  <meta name="generator" content="Nicepage 3.9.3, nicepage.com">
  <link id="u-theme-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Barlow:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
  <link id="u-page-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Barlow:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">

    <style>
      * {
        box-sizing: border-box;
      }
      
      body {
        margin: 0;
        font-family: Arial;
      }
      
      .header {
        text-align: center;
        padding: 32px;
      }
      
      .row {
        display: -ms-flexbox; /* IE10 */
        display: flex;
        -ms-flex-wrap: wrap; /* IE10 */
        flex-wrap: wrap;
        padding: 0 4px;
      }
      
      /* Create four equal columns that sits next to each other */
      .column {
        -ms-flex: 25%; /* IE10 */
        flex: 25%;
        max-width: 25%;
        padding: 0 4px;
      }
      
      .column img {
        margin-top: 8px;
        vertical-align: middle;
        width: 100%;
      }
      
      /* Responsive layout - makes a two column-layout instead of four columns */
      @media  screen and (max-width: 800px) {
        .column {
          -ms-flex: 50%;
          flex: 50%;
          max-width: 50%;
        }
      }
      
      /* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
      @media  screen and (max-width: 600px) {
        .column {
          -ms-flex: 100%;
          flex: 100%;
          max-width: 100%;
        }
      }
      </style>
 <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"url": "index.html"
}</script>
  <meta property="og:title" content="Page 2">
  <meta property="og:type" content="website">
  <meta name="theme-color" content="#29b7dd">
  <link rel="canonical" href="index.html">
  <meta property="og:url" content="index.html">

  <?php }else{?>

        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard - SB Admin</title>
        <?php echo link_tag('components/assets/css/styles.css')?>
        <script src = "https://code.jquery.com/jquery-3.5.1.js"></script> 
        <script src = "https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script> 
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>

        <meta charset="utf-8">
        <!--[if IE]>
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <![endif]-->
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="shortcut icon" href="http://localhost/e-waste/components/assets/images/favicon.png">
        <link href="http://localhost/e-waste/components/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="http://localhost/e-waste/components/assets/css/animations.css" rel="stylesheet" type="text/css" />
        <link href="http://localhost/e-waste/components/assets/css/fonts.css" rel="stylesheet" type="text/css" />
        <!-- <link href="http://localhost/e-waste/components/assets/css/main.css" class="color-switcher-link" rel="stylesheet" type="text/css" /> -->
        <link href="http://localhost/e-waste/components/assets/css/datatables/datatable.css" rel="stylesheet" type="text/css" />

        <script src="http://localhost/e-waste/components/assets/js/vendor/modernizr-2.6.2.min.js"></script>

        <link href="http://localhost/e-waste/components/assets/css/dashboard.css" class="color-switcher-link" rel="stylesheet" type="text/css" />

        <!--[if lt IE 9]>
            <script src="http://localhost/e-waste/components/assets/js/vendor/html5shiv.min.js"></script>
            <script src="http://localhost/e-waste/components/assets/js/vendor/respond.min.js"></script>
            <script src="http://localhost/e-waste/components/assets/js/vendor/jquery-1.12.4.min.js"></script>
        <![endif]-->
        <?php }?>